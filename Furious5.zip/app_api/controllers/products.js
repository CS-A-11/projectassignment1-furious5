var mongoose = require("mongoose");
var proc = mongoose.model("Product");

var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

/*module.exports.productsCreate = function(req, res) {
  proc.create(
    {
      name: req.body.name,
      price: req.body.price,
      rating: req.body.rating,
      quantity: req.body.quantity,
      category: req.body.category
    },
    function(error, user) {
      if (error) {
        sendJSONresponse(res, 400, err);
      } else {
        req.session.userId = user._id;
        sendJSONresponse(res, 200, { status: "success" });
      }
    }
  );
};*/

// module.exports.productsListByDistance = function(req, res) {
//   sendJsonResponse(res, 200, { status: "success" });
// };
/* GET list of products */
module.exports.productsListByDistance = function(req, res) {
  proc.find().exec(function(err, products) {
    if (products.length == 0) {
      // sendJSONresponse(res, 404, {
      //   message: "products not found"
      // });
      // return;
      proc.create(
        [
          {
            name: "Fidget Spinner",
            price: 1200,
            rating: 2,
            category: "Toys",
            quantity: 20
          },
          {
            name: "Bracelet",
            category: "Electronics",
            price: 1200,
            rating: 5,
            quantity: 10
          }
        ],
        function(error, locs) {
          if (error) {
            sendJSONresponse(res, 400, err);
          } else {
            products = locs;
            sendJSONresponse(res, 200, products);
          }
        }
      );
    } else if (products) sendJSONresponse(res, 200, products);
    else if (err) {
      console.log(err);
      sendJSONresponse(res, 404, err);
      return;
    }
  });
};
/* GET a product by the id */
module.exports.productsReadOne = function(req, res) {
  console.log("Finding product details", req.params);
  if (req.params && req.params.productid) {
    proc.findById(req.params.productid).exec(function(err, product) {
      if (!product) {
        sendJSONresponse(res, 404, {
          message: "productid not found"
        });
        return;
      } else if (err) {
        console.log(err);
        sendJSONresponse(res, 404, err);
        return;
      }
      console.log(product);
      sendJSONresponse(res, 200, product);
    });
  } else {
    console.log("No productid specified");
    sendJSONresponse(res, 404, {
      message: "No productid in request"
    });
  }
};

/* POST a new product */
/* /api/products */
module.exports.productsCreate = function(req, res) {
  console.log(req.body);
  proc.create(
    {
      name: req.body.name,
      price: req.body.price,
      rating: req.body.rating,
      quantity: req.body.quantity,
      category: req.body.category
    },
    function(err, product) {
      if (err) {
        console.log(err);
        sendJSONresponse(res, 400, err);
      } else {
        console.log(product);
        sendJSONresponse(res, 201, product);
      }
    }
  );
};

/* PUT /api/products/:productid */
module.exports.productsUpdateOne = function(req, res) {
  if (!req.params.productid) {
    sendJSONresponse(res, 404, {
      message: "Not found, productid is required"
    });
    return;
  }
  proc.findById(req.params.productid)
    .select("-reviews -rating")
    .exec(function(err, product) {
      if (!product) {
        sendJSONresponse(res, 404, {
          message: "productid not found"
        });
        return;
      } else if (err) {
        sendJSONresponse(res, 400, err);
        return;
      }
      product.name = req.body.name,
      product.category = req.body.category,
      product.price = req.body.price

      product.save(function(err, product) {
        if (err) {
          sendJSONresponse(res, 404, err);
        } else {
          sendJSONresponse(res, 200, product);
        }
      });
    });
};

/* DELETE /api/products/:productid */
module.exports.productsDeleteOne = function(req, res) {
  var productid = req.params.productid;
  if (productid) {
    proc.findByIdAndRemove(productid).exec(function(err, product) {
      if (err) {
        console.log(err);
        sendJSONresponse(res, 404, err);
        return;
      }
      console.log("procation id " + productid + " deleted");
      sendJSONresponse(res, 204, null);
    });
  } else {
    sendJSONresponse(res, 404, {
      message: "No productid"
    });
  }
};
module.exports.productsUpdateQuantity = function(req, res) {
  if (!req.params.productid) {
    sendJSONresponse(res, 404, {
      message: "Not found, productid is required"
    });
    return;
  }
  cart
  .findById(req.params.productid)
    .exec(function(err, product) {
      if (!product) {
        sendJSONresponse(res, 404, {
          message: "productid not found"
        });
        return;
      } else if (err) {
        sendJSONresponse(res, 400, err);
        return;
      }
    product.quantity = req.body.quantity; //product.quantity - req.body.quantity???
    
      product.save(function(err, product) {
        if (err) {
          sendJSONresponse(res, 404, err);
        } else {
          sendJSONresponse(res, 200, product);
        }
      });
    });
};
