var express = require("express");
var router = express.Router();
var ctrlProducts = require("../controllers/products");
var ctrlOthers = require("../controllers/others");
var ctrlMain = require("../controllers/main");

/* products pages */

router.get("/", ctrlProducts.homelist);
router.get("/product/:productid", ctrlProducts.productInfo);
router.get(
  "/product/:productid/review/new",
  ctrlProducts.checkLogin,
  ctrlProducts.addReview
);
router.get("/prodcreate",ctrlProducts.renderProductForm)
router.post("/prodcreate",ctrlProducts.doProdCreate)

router.post("/product/:productid/review/new", ctrlProducts.doAddReview);

router.get(
  "/product/:productid/review/:reviewid/edit",
  ctrlProducts.editReview
);
router.post(
  "/product/:productid/review/:reviewid/edit",
  ctrlProducts.doEditReview
);

router.get(
  "/product/:productid/review/:reviewid/delete",
  ctrlProducts.deleteReview
);
router.get(
	"/product/:productid/addToCart",ctrlProducts.checkLogin,
	ctrlProducts.addToCart
);

router.get("/main", ctrlMain.index);
/* Other pages*/
router.get("/about", ctrlOthers.about);
router.get("/login", ctrlOthers.login);
router.get("/logout", ctrlOthers.logout);
router.post("/login", ctrlOthers.doLogin);
router.get("/register", ctrlOthers.register);
router.post("/register", ctrlOthers.doRegister);
router.get("/prodFormBack", ctrlProducts.justRender);
module.exports = router;
