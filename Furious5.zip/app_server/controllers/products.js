var request = require("request");
var apiOptions = {
  server: "http://localhost:3000"
};
if (process.env.NODE_ENV === "production") {
  apiOptions.server = "http://localhost/Daraz";
}

var mongoose = require("mongoose");
//var productmodel = require("../models/products");
var proc = mongoose.model("Product");

var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

var _showError = function(req, res, status) {
  var title, content;
  if (status === 404) {
    title = "404, page not found";
    content = "Oh dear. Looks like we can't find this page. Sorry.";
  } else if (status === 500) {
    title = "500, internal server error";
    content = "How embarrassing. There's a problem with our server.";
  } else {
    title = status + ", something's gone wrong";
    content = "Something, somewhere, has gone just a little bit wrong.";
  }
  res.status(status);
  res.render("generic-text", {
    title: title,
    content: content
  });
};
/* GET 'home' page */
module.exports.homelist = function(req, res) {
  var requestOptions, path;
  path = "/api/products";
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var i, data;
    data = body;
    if (response.statusCode === 200 && data.length) {
      for (i = 0; i < data.length; i++) {
        //data[i].distance = _formatDistance(data[i].distance);
      }
    }
    renderHomepage(req, res, data);
  });
};
var renderHomepage = function(req, res, responseBody) {
  var message;
  if (!(responseBody instanceof Array)) {
    message = "API lookup error";
    responseBody = [];
  } else {
    if (!responseBody.length) {
      message = "No products found in database";
    }
  }
  res.render("products-list", {
    title: "Daraz - Pakistan's largest e-commerce website",
    pageHeader: {
      title: "Daraz",
      strapline: "Shop! Shop! Shop!"
    },
    sidebar:
      "This website is a replication of the Pakistan's largest e-commerce website - Daraz.",
    products: responseBody,
    message: message
  });
};

var getProductInfo = function(req, res, callback) {
  var requestOptions, path;
  path = "/api/products/" + req.params.productid;
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};

var renderDetailPage = function(req, res, prodDetail) {
  res.render("product-info", {
    title: prodDetail.name,
    pageHeader: { title: prodDetail.name },
    sidebar: {
      context:
        "All the products on this website are original",
      callToAction:
        "If you've bought a product and you like it - or if you don't - please leave a review to help other people just like you."
    },
    product: prodDetail
  });
};

/* GET 'Product info' page */
module.exports.productInfo = function(req, res) {
    getProductInfo(req, res, function(req, res, responseData) {
    renderDetailPage(req, res, responseData);
  });
};

var renderReviewForm = function(req, res, prodDetail) {
  res.render("product-review-form", {
    title: "Review " + prodDetail.name + " on Daraz",
    pageHeader: { title: "Review " + prodDetail.name },
    review: {},

    error: req.query.err
  });
};

var renderEditReviewForm = function(req, res, reviewDetail) {
  res.render("product-review-edit-form", {
    title: "Review " + reviewDetail.product.name + " on Daraz",
    pageHeader: { title: "Review " + reviewDetail.product.name },
    author: reviewDetail.review.author,
    rating: reviewDetail.review.rating,
    reviewText: reviewDetail.review.reviewText,
    error: req.query.err
  });
};
module.exports.checkLogin = function requiresLogin(req, res, next) {
  //
  if (req.session && req.session.userId) {
    console.log("session active");
    next();
  } else {
    console.log("no session active");
    var err = new Error("You must be logged in to view this page.");
    err.status = 401;
    res.redirect("/login");
  }
};

/* GET 'Add review' page */
module.exports.addReview = function(req, res) {
  getProductInfo(req, res, function(req, res, responseData) {
    renderReviewForm(req, res, responseData);
  });
};

/* POST 'Add review' page */
module.exports.doAddReview = function(req, res) {
  var requestOptions, path, productid, postdata;
  productid = req.params.productid;
  path = "/api/products/" + productid + "/reviews";
  postdata = {
    author: req.body.name,
    rating: parseInt(req.body.rating, 10),
    reviewText: req.body.review,
    userId: req.session.userId
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  if (!postdata.author || !postdata.rating || !postdata.reviewText) {
    res.redirect("/product/" + productid + "/reviews/new?err=val");
  } else {
    request(requestOptions, function(err, response, body) {
      if (response.statusCode === 201) {
        res.redirect("/product/" + productid);
      } else if (
        response.statusCode === 400 &&
        body.name &&
        body.name === "ValidationError"
      ) {
        res.redirect("/product/" + productid + "/reviews/new?err=val");
      } else {
        console.log(body);
        _showError(req, res, response.statusCode);
      }
    });
  }
};

/* GET 'Edit review' page */
module.exports.editReview = function(req, res) {
  getReviewInfo(req, res, function(req, res, responseData) {
    renderEditReviewForm(req, res, responseData);
  });
};

/* GET 'Delete review' page */
module.exports.deleteReview = function(req, res) {
  var requestOptions, path, productid, reviewid;
  productid = req.params.productid;
  reviewid = req.params.reviewid;
  path = "/api/products/" + productid + "/reviews/" + reviewid;

  requestOptions = {
    url: apiOptions.server + path,
    method: "DELETE",
    json: {}
  };

  request(requestOptions, function(err, response) {
    if (response.statusCode === 204) {
      res.redirect("/product/" + productid);
    } else if (response.statusCode === 400) {
      res.redirect("/product/" + productid + "/reviews/new?err=val");
    } else {
      //console.log(body);
      _showError(req, res, response.statusCode);
    }
  });
};

var getReviewInfo = function(req, res, callback) {
  var requestOptions, path;
  path =
    "/api/products/" +
    req.params.productid +
    "/reviews/" +
    req.params.reviewid;
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};

/* PUT 'Edit review' page */
module.exports.doEditReview = function(req, res) {
  var requestOptions, path, productid, reviewid, postdata;
  productid = req.params.productid;
  reviewid = req.params.reviewid;
  path = "/api/products/" + productid + "/reviews/" + reviewid;
  postdata = {
    author: req.body.name,
    rating: parseInt(req.body.rating, 10),
    reviewText: req.body.review
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "PUT",
    json: postdata
  };
  if (!postdata.author || !postdata.rating || !postdata.reviewText) {
    res.redirect("/product/" + productid + "/reviews/new?err=val");
  } else {
    request(requestOptions, function(err, response, body) {
      if (response.statusCode === 200) {
        res.redirect("/product/" + productid);
      } else if (
        response.statusCode === 400 &&
        body.name &&
        body.name === "ValidationError"
      ) {
        res.redirect("/product/" + productid + "/reviews/new?err=val");
      } else {
        console.log(body);
        _showError(req, res, response.statusCode);
      }
    });
  }
};

module.exports.renderProductForm = function(req, res){
  res.render("productForm");
}

module.exports.doProdCreate = function(req, res) {
  var requestOptions, path, postdata;
  path = "/api/products/create";
  postdata = {
    name: req.body.name,
    price: req.body.price,
    rating: req.body.rating,
    quantity: req.body.quantity,
    category: req.body.category
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  request(requestOptions, function(err, response, body) {
    if (response.statusCode === 201) {
      res.redirect("/prodFormBack");
    }
    else if (err){
      res.redirect("/prodcreate");
    }
    else{
      res.redirect("/prodcreate");
    }
  });
};

module.exports.justRender = function(req, res) {
  res.render("prodFormBack");
};
module.exports.addToCart = function(req, res) {
}