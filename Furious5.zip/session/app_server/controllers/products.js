var request = require("request");
var apiOptions = {
  server: "http://localhost:3000"
};
if (process.env.NODE_ENV === "production") {
  apiOptions.server = "http://localhost/Daraz";
}


var mongoose = require("mongoose");
//var productmodel = require("../models/products");
var proc = mongoose.model("Product");


var sendJSONresponse = function(res, status, content) {
  console.log("Send JSON called");
  res.status(status);
  
  console.log(content);
  //res.json(content);
  res.send(content);
  console.log("Send JSON exited");
};

var _showError = function(req, res, status) {
  var title, content;
  if (status === 404) {
    title = "404, page not found";
    content = "Oh dear. Looks like we can't find this page. Sorry.";
  } else if (status === 500) {
    title = "500, internal server error";
    content = "How embarrassing. There's a problem with our server.";
  } else {
    title = status + ", something's gone wrong";
    content = "Something, somewhere, has gone just a little bit wrong.";
  }
  res.status(status);
  res.render("generic-text", {
    title: title,
    content: content
  });
};
/* GET 'home' page */
module.exports.homelist = function(req, res) {
  var requestOptions, path;
  path = "/api/products";
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var i, data;
    data = body;
    if (response && response.statusCode === 200 && data.length) {
      for (i = 0; i < data.length; i++) {
        //data[i].distance = _formatDistance(data[i].distance);
      }
    }
    renderHomepage(req, res, data);
  });
};
var renderHomepage = function(req, res, responseBody) {
  var message;
  if (!(responseBody instanceof Array)) {
    message = "API lookup error";
    responseBody = [];
  } else {
    if (!responseBody.length) {
      message = "No products found in database";
    }
  }
  res.render("products-list", {
    title: "Daraz - Pakistan's largest e-commerce website",
    pageHeader: {
      title: "Daraz",
      strapline: "Shop! Shop! Shop!"
    },
    sidebar:
      "This website is a replication of the Pakistan's largest e-commerce website - Daraz.",
    products: responseBody,
    message: message
  });
};


module.exports.DisplayOrders = function(req, res) {
  var requestOptions, path;
  path = "/api/ShowOrder";
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var i, data;
    data = body;
    renderOrdersPage(req, res, data);
  });
};
var renderOrdersPage = function(req, res, responseBody) {
  var message;
  if (!(responseBody instanceof Array)) {
    message = "API lookup error";
    responseBody = [];
  } else {
    if (!responseBody.length) {
      message = "No products found in database";
    }
  }
  res.render("DisplayAllOrders", {
    Orders: responseBody,
    message: message
  });
};

var DeleteCart = function(req, res) {
  console.log("Delete cart has been started");
  var requestOptions, path;
  path = "/api/DeleteCart";
  requestOptions = {
    url: apiOptions.server + path,
    method: "DELETE",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var i, data;
    data = body;
  });
};

var getCart = function(req, res, callback) {
  console.log("Getcart has been called");
  var requestOptions, path;
  path = "/api/carts";
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    console.log(data[0].name);
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};


var getProductInfo = function(req, res, callback) {
  var requestOptions, path;
  path = "/api/products/" + req.params.productid;
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};

var renderDetailPage = function(req, res, prodDetail) {
  
  res.render("product-info", {
    //Stock available is undefined
    title: prodDetail.name,
    pageHeader: { title: prodDetail.name, Price: prodDetail.price },
    sidebar: {
      context:
        "Price " + prodDetail.price + "\n" + "Stock Available ",
      callToAction:
        "If you've bought a product and you like it - or if you don't - please leave a review to help other people just like you."
      
    },
    product: prodDetail
    
  });
};



module.exports.renderCarts = function(req, res) {
  var requestOptions, path;
  path = "/api/carts";
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var i, data;
    data = body;
    renderCart(req, res, data);
  });
};
var renderCart = function(req, res, prodDetail) {
  var message;
  if (!(prodDetail instanceof Array)) {
    message = "API lookup error";
    prodDetail = [];
  } else {
    if (!prodDetail.length) {
      message = "No products found in database";
    }
  }
  console.log("Entered renderCart.");
  
  console.log(prodDetail.length);
  res.render("Cart", {
  //Stock available is undefined
    
    carts: prodDetail,
    message: message
  
});
};


// var renderCart = function(req, res, responseBody) {
//   var message;
//   if (!(responseBody instanceof Array)) {
//     message = "API lookup error";
//     responseBody = [];
//   } else {
//     if (!responseBody.length) {
//       message = "No products found in database";
//     }
//   }
//   res.render("/cart", {
//     cart: responseBody
//   });
// };

module.exports.doCartCreate = function(req, res) {
  getProductInfo(req, res, function(req, res, responseData) {



    var requestOptions, path, postdata;
    path = "/api/createcart";
    postdata = {
      name: responseData.name,
      price: responseData.price,
      quantity: responseData.quantity,
      Selected: 1
    };
    console.log("POSTDATA.NAME is displayed below");
    console.log(postdata.name + postdata.price + postdata.quantity + postdata.Selected);
    requestOptions = {
      url: apiOptions.server + path,
      method: "POST",
      json: postdata
    };
    console.log("Bhej deya data");
    // res.redirect("/");
    request(requestOptions, function(err, response, body) {
      var data = body;
      if (response.statusCode === 200) {
        callback(req, res, data);
      } else {
        _showError(req, res, response.statusCode);
      }
    });


    
    res.redirect("/");
});
};

module.exports.personalDetails = function(req,res) {
  
  
  res.render("details",{

  });
}








// module.exports.OrderCreate = function(req, res) {
//   POSTProductInfo(req, res, function(req, res, responseData) {
//   renderCart(req, res, responseData);
// });
// };
/* GET 'Product info' page */
module.exports.productInfo = function(req, res) {
    getProductInfo(req, res, function(req, res, responseData) {
    renderDetailPage(req, res, responseData);
  });
};

var renderReviewForm = function(req, res, prodDetail) {
  res.render("product-review-form", {
    title: "Review " + prodDetail.name + " on Daraz",
    pageHeader: { title: "Review " + prodDetail.name },
    review: {},

    error: req.query.err
  });
};

var renderEditReviewForm = function(req, res, reviewDetail) {
  res.render("product-review-edit-form", {
    title: "Review " + reviewDetail.product.name + " on Daraz",
    pageHeader: { title: "Review " + reviewDetail.product.name },
    author: reviewDetail.review.author,
    rating: reviewDetail.review.rating,
    reviewText: reviewDetail.review.reviewText,
    error: req.query.err
  });
};
module.exports.checkLogin = function requiresLogin(req, res, next) {
  //
  if (req.session && req.session.userId) {
    console.log("session active");
    next();
  } else {
    console.log("no session active");
    var err = new Error("You must be logged in to view this page.");
    err.status = 401;
    res.redirect("/login");
  }
};

/* GET 'Add review' page */
module.exports.addReview = function(req, res) {
  getProductInfo(req, res, function(req, res, responseData) {
    renderReviewForm(req, res, responseData);
  });
};

/* POST 'Add review' page */
module.exports.doAddReview = function(req, res) {
  var requestOptions, path, productid, postdata;
  productid = req.params.productid;
  path = "/api/products/" + productid + "/reviews";
  postdata = {
    author: req.body.name,
    rating: parseInt(req.body.rating, 10),
    reviewText: req.body.review,
    userId: req.session.userId
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  if (!postdata.author || !postdata.rating || !postdata.reviewText) {
    res.redirect("/product/" + productid + "/reviews/new?err=val");
  } else {
    request(requestOptions, function(err, response, body) {
      if (response.statusCode === 201) {
        res.redirect("/product/" + productid);
      } else if (
        response.statusCode === 400 &&
        body.name &&
        body.name === "ValidationError"
      ) {
        res.redirect("/product/" + productid + "/reviews/new?err=val");
      } else {
        console.log(body);
        _showError(req, res, response.statusCode);
      }
    });
  }
};

module.exports.OrderCreate = function(req, res) {
  var requestOptions, path, productid, postdata;
  productid = req.params.productid;
  path = "/api/checkout/";
  postdata = {
    author: req.body.name,
    rating: parseInt(req.body.rating, 10),
    reviewText: req.body.review,
    userId: req.session.userId
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  if (!postdata.author || !postdata.rating || !postdata.reviewText) {
    res.redirect("/product/" + productid + "/reviews/new?err=val");
  } else {
    request(requestOptions, function(err, response, body) {
      if (response.statusCode === 201) {
        res.redirect("/product/" + productid);
      } else if (
        response.statusCode === 400 &&
        body.name &&
        body.name === "ValidationError"
      ) {
        res.redirect("/product/" + productid + "/reviews/new?err=val");
      } else {
        console.log(body);
        _showError(req, res, response.statusCode);
      }
    });
  }
};

/* GET 'Edit review' page */
module.exports.editReview = function(req, res) {
  getReviewInfo(req, res, function(req, res, responseData) {
    renderEditReviewForm(req, res, responseData);
  });
};

/* GET 'Delete review' page */
module.exports.deleteReview = function(req, res) {
  var requestOptions, path, productid, reviewid;
  productid = req.params.productid;
  reviewid = req.params.reviewid;
  path = "/api/products/" + productid + "/reviews/" + reviewid;

  requestOptions = {
    url: apiOptions.server + path,
    method: "DELETE",
    json: {}
  };

  request(requestOptions, function(err, response) {
    if (response.statusCode === 204) {
      res.redirect("/product/" + productid);
    } else if (response.statusCode === 400) {
      res.redirect("/product/" + productid + "/reviews/new?err=val");
    } else {
      //console.log(body);
      _showError(req, res, response.statusCode);
    }
  });
};

var getReviewInfo = function(req, res, callback) {
  var requestOptions, path;
  path =
    "/api/products/" +
    req.params.productid +
    "/reviews/" +
    req.params.reviewid;
  requestOptions = {
    url: apiOptions.server + path,
    method: "GET",
    json: {}
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};

/* PUT 'Edit review' page */
module.exports.doEditReview = function(req, res) {
  var requestOptions, path, productid, reviewid, postdata;
  productid = req.params.productid;
  reviewid = req.params.reviewid;
  path = "/api/products/" + productid + "/reviews/" + reviewid;
  postdata = {
    author: req.body.name,
    rating: parseInt(req.body.rating, 10),
    reviewText: req.body.review
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "PUT",
    json: postdata
  };
  if (!postdata.author || !postdata.rating || !postdata.reviewText) {
    res.redirect("/product/" + productid + "/reviews/new?err=val");
  } else {
    request(requestOptions, function(err, response, body) {
      if (response.statusCode === 200) {
        res.redirect("/product/" + productid);
      } else if (
        response.statusCode === 400 &&
        body.name &&
        body.name === "ValidationError"
      ) {
        res.redirect("/product/" + productid + "/reviews/new?err=val");
      } else {
        console.log(body);
        _showError(req, res, response.statusCode);
      }
    });
  }
};

module.exports.renderProductForm = function(req, res){
  res.render("productForm");
}
module.exports.renderCartForm = function(req, res){
  
  var requestOptions, path, postdata;
  path = "/api/products/addtocart";
  postdata = {
    id: req.params.productid
  };
  console.log("Before calling api");
  console.log(postdata.id);
  sessions.cart = postdata;
  //res.redirect("/cart");
  console.log("Entered in doCartCreate");
  console.log(postdata.name + postdata.price + postdata.stock + postdata.selected);
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
  res.redirect("/cart");
}

module.exports.doProdCreates = function(req, res) {
  res.render("productForm");
  };


module.exports.doProdCreate = function(req, res) {
  var requestOptions, path, postdata;
  path = "/api/products/create";
  postdata = {
    name: req.body.name,
    price: req.body.price,
    rating: req.body.rating,
    quantity: req.body.quantity,
    productImg: req.body.url,
    category: req.body.category
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    }
    else if (response.statusCode === 201){
      res.redirect("/prodFormBack");
    }
    else {
      _showError(req, res, response.statusCode);
    }
  });
};

module.exports.doOrderCreate = function(req, res) {
  var requestOptions, path, postdata;
  path = "/api/finally";
  postdata = {
    name: req.body.name,
      address:req.body.address
  };
  console.log(postdata.name + postdata.price);
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };
  res.redirect("/Orders");
  request(requestOptions, function(err, response, body) {
    var data = body;
    if (response.statusCode === 200) {
      callback(req, res, data);
    } else {
      _showError(req, res, response.statusCode);
    }
  });
};

module.exports.finally = function(req, res) {
  console.log("App_Server ka controller product finally ran");
  getCart(req, res, function(req, res, responseData) {
    console.log("App_Server ka controller product getCart ran");
    console.log(responseData[0].name);
    var requestOptions, path, postdata;
    path = "/api/finally";
    postdata = {
      name: req.session.userName,
      address: " ",
      cart: responseData
    };
    console.log("POSTDATA.NAME is displayed below");
    console.log(postdata.name + postdata.address + postdata.cart[0].name);
    requestOptions = {
      url: apiOptions.server + path,
      method: "POST",
      json: postdata
    };
    console.log("Bhej deya data");    
    request(requestOptions, function(err, response, body) {
      var data = body;
      if (response.statusCode === 200) {
        callback(req, res, data);
      } else {
        _showError(req, res, response.statusCode);
      }
    });
    console.log("Function has been compeleted");
    console.log("Starting Delete Function");
  DeleteCart(req, res);
    res.redirect("/Orders");
});
  
}

module.exports.addToCart = function(req, res) {
  var obj = {name: "Okay"+req.body.name, price: "Okay"+req.body.price, stock: "Okay"+req.body.stock, quan: "Okay"+req.body.quan};
  // req.session.cart = obj;
  res.send(obj);
  alert(obj.name);
}
module.exports.justRender = function(req, res) {
  res.render("prodFormBack");
};
// module.exports.doCartCreate = function(req, res) {
//   var postdata;
  
//   console.log(req.params.productid);
//   postdata = {
//     id: req.params.productid
    
//   };
//   console.log("Before calling api");
//   console.log(req.params.productid);
  


//   request(requestOptions, function(err, response, body) {
//     var data = body;
//     if (response.statusCode === 200) {
//       callback(req, res, data);
//     } else {
//       _showError(req, res, response.statusCode);
//     }
//   });
  
//   //CRUD


//   // console.log("Finding product details", req.params);
//   // if (req.params && req.params.productid) {
//   //   proc.findById(req.params.productid).exec(function(err, product) {
//   //     if (!product) {
//   //       sendJSONresponse(res, 404, {
//   //         message: "productid not found"
//   //       });
//   //       return;
//   //     } else if (err) {
//   //       console.log(err);
//   //       sendJSONresponse(res, 404, err);
//   //       return;
//   //     }
//   //     console.log(product);
//   //     sendJSONresponse(res, 200, product);
//   //     console.log("Catch me if you can");
//   //   });
//   // } else {
//   //   console.log("No productid specified");
//   //   sendJSONresponse(res, 404, {
//   //     message: "No productid in request"
//   //   });
//   // }


//   //CRUD
//   console.log("Entered in doCartCreate");
  
//   res.redirect("/cart");
// };