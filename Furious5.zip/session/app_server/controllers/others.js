var request = require("request");
var apiOptions = {
  server: "http://localhost:3000"
};
//if (process.env.NODE_ENV === "production") {
 // apiOptions.server = process.env.MONGODB_URI;
//}

/* GET 'about us' page */
module.exports.about = function(req, res) {
  res.render("generic-text", {
    title: "About Daraz",
    content:
      "This website is a replication of the largest e-commerce website of Pakistan - Daraz."
  });
};



module.exports.login = function(req, res) {
  res.render("login-page", {
    pageHeader: { title: "Login " }
  });
};

module.exports.logout = function(req, res) {
  if (req.session) {
    console.log("destroying session " + req.session.userId);
    // delete session object
    req.session.destroy();
    res.locals.user = undefined;
    res.redirect("/");
  }
};

module.exports.register = function(req, res) {
  res.render("register-page", {
    pageHeader: { title: "Register " }
  });
};

module.exports.doRegister = function(req, res) {
  var requestOptions, path, postdata;
  path = "/api/users/new";
  postdata = {
    email: req.body.email,
    name: req.body.name,
    password: req.body.pass
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };

  request(requestOptions, function(err, response, body) {
    if (response.statusCode === 200) {
      res.redirect("/login");
    }
    else if (response.statusCode === 400){
      res.render("renderError")
    }
  });
};

module.exports.doLogin = function(req, res) {
  var requestOptions, path, postdata;
  path = "/api/users/login";
  postdata = {
    email: req.body.email,
    password: req.body.pass
  };
  requestOptions = {
    url: apiOptions.server + path,
    method: "POST",
    json: postdata
  };

  request(requestOptions, function(err, response, body) {
    if (response.statusCode === 200) {
      console.log(body);
      req.session.userId = body._id;
      req.session.userName = body.username;

      console.log("user session id assigned" + req.session.userId);
      res.redirect("/");
    }
  });
};
