var mongoose = require("mongoose");

var cartSchema = new mongoose.Schema({
    name: {type: String, required: true},
	price: Number,
    stock: Number,
    quantity: {type: Number, "default": 1}
});

var Cart = mongoose.model("Cart", cartSchema);
module.exports = Cart;

