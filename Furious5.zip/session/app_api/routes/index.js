var express = require("express");
var router = express.Router();
var ctrlProducts = require("../controllers/products");
var ctrlReviews = require("../controllers/reviews");
var ctrlUsers = require("../controllers/users");

router.get("/products", ctrlProducts.productsListByDistance);
router.get("/ShowOrder", ctrlProducts.OrderReadAll);
router.post("/products/create", ctrlProducts.productsCreate);
// router.get("/products/addtocart/:name/:price/:stock/:quan", ctrlProducts.addtoCart);
router.post("/createcart", ctrlProducts.cartCreate);
// router.post("/checkout", ctrlProducts.OrderCreate);



router.delete("/DeleteCart", ctrlProducts.CartDelete);
router.get("/carts", ctrlProducts.cartReadAll);
router.post("/finally", ctrlProducts.finally);
router.get("/products/:productid", ctrlProducts.productsReadOne);
router.put("/products/:productid", ctrlProducts.productsUpdateOne);
router.delete("/products/:productid", ctrlProducts.productsDeleteOne);

// reviews
router.post("/products/:productid/reviews", ctrlReviews.reviewsCreate);
router.get(
  "/products/:productid/reviews/:reviewid",
  ctrlReviews.reviewsReadOne
);
router.put(
  "/products/:productid/reviews/:reviewid",
  ctrlReviews.reviewsUpdateOne
);
router.delete(
  "/products/:productid/reviews/:reviewid",
  ctrlReviews.reviewsDeleteOne
);

//user login/register routes
router.post("/users/new", ctrlUsers.userCreate);
router.post("/users/login", ctrlUsers.userLogin);
module.exports = router;
