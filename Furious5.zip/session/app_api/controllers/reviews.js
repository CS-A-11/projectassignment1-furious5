var mongoose = require("mongoose");
var Product = mongoose.model("Product");

var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

/* POST a new review, providing a productid */
/* /api/products/:productid/reviews */
module.exports.reviewsCreate = function(req, res) {
  if (req.params.productid) {
    Product.findById(req.params.productid)
      .select("reviews")
      .exec(function(err, product) {
        if (err) {
          sendJSONresponse(res, 400, err);
        } else {
          doAddReview(req, res, product);
        }
      });
  } else {
    sendJSONresponse(res, 404, {
      message: "Not found, productid required"
    });
  }
};

var doAddReview = function(req, res, product) {
  if (!product) {
    sendJSONresponse(res, 404, "productid not found");
  } else {
    console.log("In add review " + req.body.userId);
    console.log(res.locals.user);
    product.reviews.push({
      author: req.body.author,
      rating: req.body.rating,
      reviewText: req.body.reviewText,
      userId: req.body.userId
    });
    product.save(function(err, product) {
      var thisReview;
      if (err) {
        sendJSONresponse(res, 400, err);
      } else {
        updateAverageRating(product._id);
        thisReview = product.reviews[product.reviews.length - 1];
        sendJSONresponse(res, 201, thisReview);
      }
    });
  }
};

var updateAverageRating = function(productid) {
  console.log("Update rating average for", productid);
  Product.findById(productid)
    .select("reviews")
    .exec(function(err, product) {
      if (!err) {
        doSetAverageRating(product);
      }
    });
};

var doSetAverageRating = function(product) {
  var i, reviewCount, ratingAverage, ratingTotal;
  if (product.reviews && product.reviews.length > 0) {
    reviewCount = product.reviews.length;
    ratingTotal = 0;
    for (i = 0; i < reviewCount; i++) {
      ratingTotal = ratingTotal + product.reviews[i].rating;
    }
    ratingAverage = parseInt(ratingTotal / reviewCount, 10);
    product.rating = ratingAverage;
    product.save(function(err) {
      if (err) {
        console.log(err);
      } else {
        console.log("Average rating updated to", ratingAverage);
      }
    });
  }
};

module.exports.reviewsUpdateOne = function(req, res) {
  if (!req.params.productid || !req.params.reviewid) {
    sendJSONresponse(res, 404, {
      message: "Not found, productid and reviewid are both required"
    });
    return;
  }
  Product.findById(req.params.productid)
    .select("reviews")
    .exec(function(err, product) {
      var thisReview;
      if (!product) {
        sendJSONresponse(res, 404, {
          message: "productid not found"
        });
        return;
      } else if (err) {
        sendJSONresponse(res, 400, err);
        return;
      }
      if (product.reviews && product.reviews.length > 0) {
        thisReview = product.reviews.id(req.params.reviewid);
        if (!thisReview) {
          sendJSONresponse(res, 404, {
            message: "reviewid not found"
          });
        } else {
          thisReview.author = req.body.author;
          thisReview.rating = req.body.rating;
          thisReview.reviewText = req.body.reviewText;
          product.save(function(err, product) {
            if (err) {
              sendJSONresponse(res, 404, err);
            } else {
              updateAverageRating(product._id);
              sendJSONresponse(res, 200, thisReview);
            }
          });
        }
      } else {
        sendJSONresponse(res, 404, {
          message: "No review to update"
        });
      }
    });
};

module.exports.reviewsReadOne = function(req, res) {
  console.log("Getting single review");
  if (req.params && req.params.productid && req.params.reviewid) {
    Product.findById(req.params.productid)
      .select("name reviews")
      .exec(function(err, product) {
        console.log(product);
        var response, review;
        if (!product) {
          sendJSONresponse(res, 404, {
            message: "productid not found"
          });
          return;
        } else if (err) {
          sendJSONresponse(res, 400, err);
          return;
        }
        if (product.reviews && product.reviews.length > 0) {
          review = product.reviews.id(req.params.reviewid);
          if (!review) {
            sendJSONresponse(res, 404, {
              message: "reviewid not found"
            });
          } else {
            response = {
              product: {
                name: product.name,
                id: req.params.productid
              },
              review: review
            };
            sendJSONresponse(res, 200, response);
          }
        } else {
          sendJSONresponse(res, 404, {
            message: "No reviews found"
          });
        }
      });
  } else {
    sendJSONresponse(res, 404, {
      message: "Not found, productid and reviewid are both required"
    });
  }
};

// app.delete('/api/products/:productid/reviews/:reviewid'
module.exports.reviewsDeleteOne = function(req, res) {
  if (!req.params.productid || !req.params.reviewid) {
    sendJSONresponse(res, 404, {
      message: "Not found, productid and reviewid are both required"
    });
    return;
  }
  Product.findById(req.params.productid)
    .select("reviews")
    .exec(function(err, product) {
      if (!product) {
        sendJSONresponse(res, 404, {
          message: "productid not found"
        });
        return;
      } else if (err) {
        sendJSONresponse(res, 400, err);
        return;
      }
      if (product.reviews && product.reviews.length > 0) {
        if (!product.reviews.id(req.params.reviewid)) {
          sendJSONresponse(res, 404, {
            message: "reviewid not found"
          });
        } else {
          product.reviews.id(req.params.reviewid).remove();
          product.save(function(err) {
            if (err) {
              sendJSONresponse(res, 404, err);
            } else {
              updateAverageRating(product._id);
              sendJSONresponse(res, 204, null);
            }
          });
        }
      } else {
        sendJSONresponse(res, 404, {
          message: "No review to delete"
        });
      }
    });
};
