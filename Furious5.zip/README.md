## Project Title: 
Daraz: E-commerce shopping website

## Project Group Members:
Hassan Tariq  Roll No. 16L-4177
Rabiya Adnan Roll No. 16L-4356
Maham Masood Roll No. 16L-4072
Bilal Arshad Roll No. 16L-4064
Shafin Salim Roll No. 16L-4298

## UseCases: 
1. Session Management (Account System)
2. CRUD of Products
3. CRUD of Cart
4. Crud of Orders
5. CRUD of Reviews
6. AJAX/ Angular Functionalities

## Schema: 
Collections: Products, Cart, Session, Users

Nested Collections: reviews 

- Products has nested reviews
- Cart has nested products
